angular.module('Realize.prompts', [
    'Realize.Prompt.Setting',
    'Realize.Prompt.List',
    'Realize.Prompt.StateManager',
    'Realize.Prompt.promptApiUtilService',
    'Realize.Active.Discussion',
    'Realize.prompt.constants'
]);
