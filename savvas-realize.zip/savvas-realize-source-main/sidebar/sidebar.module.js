angular.module('Realize.sidebar', [
    'Realize.sidebar.PlatformSidebar',
    'Realize.sidebar.ShowSidebar',
    'Realize.sidebar.GroupsSidebarCtrl',
    'Realize.sidebar.TeacherSupportSidebarCtrl',
    'Realize.sidebar.StudentEtextToolsSidebarCtrl'
]);
