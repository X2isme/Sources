angular.module('Realize.earlyLearner.teacher', [
    'Realize.earlyLearner.teacher.config',
    'Realize.earlyLearner.teacher.earlyLearnerService',
    'Realize.earlyLearner.teacher.changeThemeCtrl'
]);
