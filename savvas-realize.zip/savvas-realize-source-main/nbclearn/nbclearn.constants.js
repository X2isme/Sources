angular.module('Realize.NbcLearn.Constants', [])
    .constant('NBCLEARN_ID', window.nbcLearnRssId)
    .constant('NBC_PROGRAM_NAME', 'NBC Learn Video Streaming');
