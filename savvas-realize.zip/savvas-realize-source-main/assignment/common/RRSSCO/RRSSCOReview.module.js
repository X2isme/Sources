angular.module('Realize.assignment.common.RRSSCOReview', [
    'Realize.assignment.common.RRSSCOReviewCtrl',
    'Realize.assignment.common.RRSSCOReview.routes',
    'Realize.common.studentNavigation'
]);
