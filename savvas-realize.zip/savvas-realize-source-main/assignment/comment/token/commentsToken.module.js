angular.module('Realize.comment.Token', [
    'Realize.comment.TokenSvc'
]);
