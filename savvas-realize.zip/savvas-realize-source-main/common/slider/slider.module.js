angular.module('Realize.slider', [
    'Realize.slider.scale',
    'Realize.slider.sliderDir'
]);
