angular.module('Realize.quicklinks', [
    'Realize.quicklinks.quickList',
    'Realize.quicklinks.quickLink',
    'Realize.quicklinks.qlClick',
    'Realize.quicklinks.quickLinkMenu'
]);
