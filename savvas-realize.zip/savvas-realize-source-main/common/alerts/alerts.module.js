angular.module('Realize.common.alerts', [
    'Realize.alerts.alertService',
    'Realize.alerts.inlineAlertService',
    'Realize.alerts.alertDirective',
    'Realize.alerts.firstVisitAlertDirective',
    'Realize.alerts.inlineNotificationDirective',
    'Realize.alerts.messageBasedAlertDirective'
]);
