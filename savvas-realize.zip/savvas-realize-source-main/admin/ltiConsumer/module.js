angular.module('Realize.admin.ltiConsumer', [
    'Realize.admin.ltiConsumer.configController',
    'Realize.admin.ltiConsumer.managementController',
    'Realize.admin.ltiConsumer.createSettingController'
]);
