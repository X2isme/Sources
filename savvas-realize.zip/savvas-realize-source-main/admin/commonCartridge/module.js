angular.module('Realize.admin.commonCartridge', [
    'Realize.admin.commonCartridge.cartridgeManagementController',
    'Realize.admin.commonCartridge.cartridgeExportController',
    'Realize.admin.commonCartridge.cartridgeRepositoryController',
    'Realize.admin.commonCartridge.createKeysController',
    'Realize.admin.commonCartridge.manageKeysController'
]);
