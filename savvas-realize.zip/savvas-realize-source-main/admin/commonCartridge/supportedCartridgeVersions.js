angular.module('Realize.admin.commonCartridge.supportedVersions', [])
    .constant('SUPPORTED_CARTRIDGE_VERSIONS', window.supportedCommonCartridgeVersions);
