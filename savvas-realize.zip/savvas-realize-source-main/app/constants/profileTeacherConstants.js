angular.module('Realize.constants.profileTeacherConstants', [])
    .constant('PROFILE_TEACHER', {
        TELEMETRY: {
            LETS_GO_BUTTON_CLICK_EVENT: 'Let\'s Go Button',
            WELCOME: 'Welcome',
        }
    });
