angular.module('Realize.constants.external', [])
    .constant('GOOGLE_DOCS_VIEWER_URL', 'https://docs.google.com/gview');
