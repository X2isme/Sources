angular.module('Realize.constants.partialsPaths', [])
    .constant('PARTIALS_PATHS', {
        'studentsAndGroupOptions': 'templates/partials/studentsAndGroupOptions.html'
    });
