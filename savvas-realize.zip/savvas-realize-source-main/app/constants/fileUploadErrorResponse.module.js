angular.module('Realize.constants.fileUploadErrorResponse', [
])
.constant('FILE_UPLOAD_ERROR_RESPONSE', {
    AV_SCAN_RESPONSE_TEXT: 'common.avs.scan.virus.detected'
});
