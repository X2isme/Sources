angular.module('Realize.constants.contribSource', [
])
.constant('CONTRIBUTOR_SOURCE', {
    PEARSON: 'Pearson',
    MY_UPLOADS: 'My Uploads'
});
