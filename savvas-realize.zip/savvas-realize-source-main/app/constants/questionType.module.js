angular.module('Realize.constants.questionType', [
])
.constant('QUESTION_TYPE', {
    MULTIPLE_CHOICE: 'multiple-choice',
    GRIDDED_RESPONSE: 'gridded-response'
});
