angular.module('Realize.calendar', [
    'Realize.calendar.classCalendarCtrl',
    'Realize.calendar.uiCalendarDirective',
    'Realize.calendar.calendarService',
    'Realize.calendar.calendarEventCtrl',
    'Realize.calendar.calendarEvent',
    'Realize.calendar.calendarEventModal',
    'Realize.calendar.eventSource',
    'Realize.calendar.routes'
]);
