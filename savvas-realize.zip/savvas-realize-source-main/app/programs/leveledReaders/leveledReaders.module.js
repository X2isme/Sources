angular.module('Realize.leveledReaders', [
    'Realize.leveledReaders.leveledReadersCtrl',
    'Realize.leveledReaders.leveledReadersSvc',
    'Realize.leveledReaders.leveledReadersScale',
    'Realize.leveledReaders.leveledReadersSearchCtrl',
    'Realize.leveledReaders.leveledReadersSearch',
    'Realize.leveledReaders.routes'
]);
