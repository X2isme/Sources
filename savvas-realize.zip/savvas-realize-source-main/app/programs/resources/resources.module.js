angular.module('Realize.resources', [
    'Realize.resources.routes',
    'Realize.resources.resourcesCtrl'
]);
