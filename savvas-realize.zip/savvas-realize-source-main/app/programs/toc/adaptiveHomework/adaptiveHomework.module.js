angular.module('Realize.adaptiveHomework', [
    'Realize.adaptiveHomework.adaptiveHomeworkCtrl',
    'Realize.adaptiveHomework.routes'
]);
