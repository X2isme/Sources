angular.module('Realize.assessment.questionBank', [
    'Realize.assessment.addQuestionBankCtrl',
    'Realize.assessment.searchBanksByTopicDirective',
    'Realize.assessment.questionBankDataService',
    'Realize.assessment.questionBankResultDirective',
    'Realize.assessment.questionBankResultService',
    'Realize.assessment.questionBankItemDirective',
    'Realize.assessment.searchBanksByStandard',
    'Realize.assessment.questionsInTestService'
]);
