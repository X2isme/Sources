angular.module('Realize.assessment.searchBanksByStandard', [
    'Realize.assessment.standardWithBankItemDirective',
    'Realize.assessment.searchBanksByStandardDirective',
    'Realize.assessment.searchByStandardService',
    'Realize.assessment.searchQuestionBankDataService'
]);
