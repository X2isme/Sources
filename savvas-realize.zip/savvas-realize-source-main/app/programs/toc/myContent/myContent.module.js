angular.module('Realize.myContent', [
    'Realize.myContent.myContentCtrl',
    'Realize.myContent.myContentDataService',
    'Realize.myContent.routes'
]);
