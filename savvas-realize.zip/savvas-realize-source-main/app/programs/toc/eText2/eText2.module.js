angular.module('Realize.eText2Builder', [
    'Realize.eText2Builder.routes',
    'Realize.eText2Builder.eText2CreateCtrl',
    'Realize.eText2Builder.eText2DataService',
    'Realize.eText2Builder.eText2BuilderService'
]);
