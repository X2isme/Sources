angular.module('Realize.discussionPrompt', [
    'Realize.discussionPrompt.discussionPromptCtrl',
    'Realize.discussionPrompt.discussionPromptResolver',
    'Realize.discussionPrompt.discussionPromptRoutes',
    'Realize.discussionPrompt.discussionPromptModel',
    'Realize.Prompt.discussionPromptQuicklink'
]);
