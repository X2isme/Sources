angular.module('Realize.eText', [
    'Realize.eText.routes',
    'Realize.eText.eTextCtrl'
]);
