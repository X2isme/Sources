angular.module('Realize.standards', [
    'Realize.standards.standardDataService',
    'Realize.standards.reviewerStandardsContentCtrl',
    'Realize.standards.standardsSearchCtrl',
    'Realize.standards.standardsTreeCtrl',
    'Realize.standards.standardTreeItemDirective',
    'Realize.standards.routes'
]);
