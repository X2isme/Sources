angular.module('Realize.header.subNav', [
    'Realize.header.subNav.classes',
    'rlzComponents.components.myLibrary.myLibrarySubnav'
]);
