angular.module('Realize.header', [
    'Realize.header.mainNav',
    'Realize.header.subNav'
]);
