angular.module('Realize.classRoster', [
    'Realize.classRoster.classDataService',
    'Realize.classRoster.classRosterTheme',
    'Realize.earlyLearner.teacher'
]);
