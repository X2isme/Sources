angular.module('Realize.recommendation', [
    'Realize.recommendation.facadeService'
]);
