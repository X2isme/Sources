angular.module('Realize.content', [
    'Realize.content.model.contentItem',
    'Realize.content.model.gooruItem',
    'Realize.content.model.openEdItem',
    'Realize.content.contentController',
    'Realize.content.contentResolver',
    'Realize.content.contentSourceService',
    'Realize.content.contentViewerService',
    'Realize.content.contentDataService',
    'Realize.content.constants',
    'Realize.content.model.questionBank',
    'Realize.content.model.questionBankItem'
]);
