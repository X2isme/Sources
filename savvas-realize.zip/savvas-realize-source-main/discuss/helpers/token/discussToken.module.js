angular.module('Realize.Discussions.Token', [
    'Realize.Discussions.TokenSvc'
]);
