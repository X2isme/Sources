angular.module('Realize.Discussions.Helpers', [
    'Realize.Discussions.Navigation',
    'Realize.Discussions.Resolve',
    'Realize.Discussions.Token',
    'Realize.Discussions.Participants'
]);
