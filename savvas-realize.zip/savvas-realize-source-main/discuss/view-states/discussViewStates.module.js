angular.module('Realize.Discussions.States', [
    'Realize.Discussions.Create',
    'Realize.Discussions.List',
    'Realize.Discussions.Thread'
]);
