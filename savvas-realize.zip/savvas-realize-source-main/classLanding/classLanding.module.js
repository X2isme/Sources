angular.module('Realize.classLanding', [
    'Realize.classLanding.teacherClassesCtrl',
    'Realize.classLanding.studentClassesCtrl'
]);
