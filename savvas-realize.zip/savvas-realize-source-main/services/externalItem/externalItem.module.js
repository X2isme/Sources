angular.module('Realize.ExternalItem', [
    'Realize.ExternalItem.DataGenerator',
    'Realize.externalItem.Strategy',
    'Realize.externalItem.OpenEd.Service'
]);

